# Commish's Thoughts

Your note shows under that trade's AI summary on the League tab. Trades without an entry show nothing.

## The file
`data/commish-thoughts.json`, keyed by trade id:

    {
      "c4865244-f4d8-4855-982d-f4a74e0f4d3f": {
        "commentary": "I think this team overpaid because the roster already has a weakness at running back.",
        "updatedAt": "2026-10-08"
      }
    }

- The key is the trade's id (ESPN's id for the accepted trade). It never changes, so a note stays with its trade. Team names are never used for matching.
- Add or edit an entry to add or change a note. Delete the entry to remove it. A blank line in the text starts a new paragraph.
- Malformed entries are ignored, and a broken file shows a note in Settings > About instead of breaking the app.
- Each trade card shows a short `#abc123` (the first six characters of its id). Full ids: open `YOUR-WORKER-URL/?view=trades&season=2026` and read the `id` of each trade (it lists who sent whom, with the date).

## How a message to Muse becomes a note
1. You message Muse about a trade and what you think.
2. Muse reads `YOUR-WORKER-URL/?view=trades&season=2026`, picks the trade whose players and teams match, and takes its `id`.
3. Muse reads `data/commish-thoughts.json` through the GitHub contents API (GET `/repos/OWNER/REPO/contents/data/commish-thoughts.json`), keeps its `sha`, changes only that one key, and writes the file back (PUT, same path, with the `sha` and a commit message like `Commish note for trade c48652`). The `sha` makes GitHub reject the write if the file changed in between, so another entry can never be overwritten.
4. GitHub Pages redeploys in a minute or two. The app reads the file fresh each time it opens, so no one has to clear a cache.
`tools/commish.py` does the same merge-safe edit from a terminal or a GitHub Action (`set`, `delete`, `validate`). A GitHub Action in `.github/workflows` validates the file on every change.

## What Muse needs (nothing is set up yet)
- A GitHub credential that can edit this one repository: a fine-grained personal access token limited to this repo with Contents set to Read and write, or a GitHub App installed on this repo with the same permission.
- That credential stored only in Muse's own secret storage. It never goes in this app, the Worker code, or the repo.
- Permission for Muse to call the GitHub API. If Muse can't, send the trade and your thoughts to Claude, or edit the file in GitHub's web editor.
- If the repo is private, GitHub Pages needs a paid GitHub plan. A private repo with a free plan can't serve the site, so keep it public or upgrade.
No public endpoint can change this file. The only way in is a commit made with your credential, and git history lets you undo any change.
