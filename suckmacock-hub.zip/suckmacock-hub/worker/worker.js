// Cloudflare Worker for The League: ESPN data in, clean JSON out.
// Secrets: ESPN_S2, SWID, GEMINI_API_KEY. Vars: LEAGUE_ID, ALLOW_ORIGIN (optional: GEMINI_MODEL). KV binding: KV (cache and weekly snapshots).
// Views: transactions (default), teams, standings, totw, gotw, trades, values, tradeai, gotwai, snapshot (GET/POST).
// Debug: ?debug=tradelog (trade records and the activity feed) and ?debug=gemini (checks the AI key).
const API = 'https://lm-api-reads.fantasy.espn.com/apis/v3/games/ffl/seasons';
const UA = 'Mozilla/5.0 (compatible; suckmacock-hub/1.0)';
const ACTIVITY = { 178: ['FREEAGENT', 'ADD'], 180: ['WAIVER', 'ADD'], 179: ['FREEAGENT', 'DROP'], 181: ['FREEAGENT', 'DROP'], 239: ['FREEAGENT', 'DROP'] };
const POS = { 1: 'QB', 2: 'RB', 3: 'WR', 4: 'TE', 5: 'K', 16: 'D/ST' };
const NFL = { 1: 'ATL', 2: 'BUF', 3: 'CHI', 4: 'CIN', 5: 'CLE', 6: 'DAL', 7: 'DEN', 8: 'DET', 9: 'GB', 10: 'TEN', 11: 'IND', 12: 'KC', 13: 'LV', 14: 'LAR',
  15: 'MIA', 16: 'MIN', 17: 'NE', 18: 'NO', 19: 'NYG', 20: 'NYJ', 21: 'PHI', 22: 'ARI', 23: 'PIT', 24: 'LAC', 25: 'SF', 26: 'SEA', 27: 'TB', 28: 'WSH',
  29: 'CAR', 30: 'JAX', 33: 'BAL', 34: 'HOU' };
const OUT = ['QB', 'RB', 'WR', 'TE', 'K'];
const CACHEABLE = ['teams', 'gotw', 'standings', 'totw', 'transactions', 'trades', 'values'];

// ---------- Gemini ----------
const TRADE_PROMPT = 'You are the sharp, witty analyst inside a private fantasy football league app. Use only the facts in the JSON you are given. ' +
  'For each team, write 2 to 3 sentences (about 60 words at most) on how this trade changes THAT team: name the players received and sent, say whether it fills a need, ' +
  'stacks a strength, thins a position, or moves a bench piece into a starting spot, and use the lineupBefore, lineupAfter and lineupChange data. ' +
  'Then write one "verdict" sentence (35 words at most) on which side comes out ahead and why. The letter grades are already calculated, so do not give grades. ' +
  'Be playful but fair, PG-13, nothing mean about real people. Return JSON only: {"sides":[{"teamId":number,"summary":string}],"verdict":string}.';
const GOTW_PROMPT = 'You write the Game of the Week preview inside a private fantasy football league app. Use only the facts in the JSON you are given. ' +
  'Write 3 to 4 sentences (90 words at most) that use the records, ranks, points per game, strongest starters, injured starters and lineupStrength to say who has the edge. ' +
  'Playfully gas up or roast each team, and end with a pick. Do not invent stats or injuries. PG-13, nothing mean about real people. Return JSON only: {"preview":string}.';
async function gemini(env, system, user, maxTokens = 1500) {
  if (!env.GEMINI_API_KEY) throw new Error('add a GEMINI_API_KEY secret to turn on AI summaries');
  const model = env.GEMINI_MODEL || 'gemini-2.5-flash';
  const generationConfig = { temperature: 0.8, maxOutputTokens: maxTokens, responseMimeType: 'application/json' };
  if (/2\.5-flash/.test(model)) generationConfig.thinkingConfig = { thinkingBudget: 0 };
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
    method: 'POST', headers: { 'x-goog-api-key': env.GEMINI_API_KEY, 'content-type': 'application/json' },
    body: JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, contents: [{ role: 'user', parts: [{ text: user }] }], generationConfig })
  });
  if (!r.ok) throw new Error('Gemini responded ' + r.status + ' ' + (await r.text()).slice(0, 160));
  const j = await r.json();
  const text = (((j.candidates || [])[0] || {}).content || { parts: [] }).parts.map(p => p.text || '').join('').replace(/```(?:json)?/g, '');
  const s = text.indexOf('{'); if (s < 0) throw new Error('Gemini did not return JSON');
  return JSON.parse(text.slice(s, text.lastIndexOf('}') + 1));
}
// The best starting lineup from a roster of {name,pos,v}, given slot counts like {QB:1,RB:2,WR:2,TE:1,FLEX:1}.
function lineupOf(players, slots) {
  const pool = players.filter(p => ['QB', 'RB', 'WR', 'TE'].includes(p.pos)).sort((a, b) => b.v - a.v), used = new Set(), starters = [];
  const fill = (slot, n, ok) => { for (let k = 0; k < n; k++) { const p = pool.find(x => !used.has(x) && ok.includes(x.pos)); if (p) { used.add(p); starters.push({ ...p, slot }); } } };
  ['QB', 'RB', 'WR', 'TE'].forEach(pos => fill(pos, slots[pos] || 0, [pos]));
  fill('FLEX', slots.FLEX || 0, ['RB', 'WR', 'TE']);
  fill('SUPERFLEX', slots.SUPERFLEX || 0, ['QB', 'RB', 'WR', 'TE']);
  return { starters, total: starters.reduce((s, p) => s + p.v, 0) };
}

const json = (d, cors, status = 200, ttl = 300) => new Response(JSON.stringify(d), {
  status, headers: { ...cors, 'Content-Type': 'application/json', 'Cache-Control': status === 200 && ttl ? `max-age=${ttl}` : 'no-store' }
});
const kvGet = async (env, k) => { if (!env.KV) return null; try { return await env.KV.get(k, 'json'); } catch (e) { return null; } };
const kvPut = async (env, k, v, ttl) => { if (!env.KV) return false; try { await env.KV.put(k, JSON.stringify(v), ttl ? { expirationTtl: ttl } : {}); return true; } catch (e) { return false; } };
const norm = s => String(s || '').toLowerCase().replace(/\b(jr|sr|ii|iii|iv|v)\b\.?/g, '').replace(/[^a-z ]/g, '').replace(/\s+/g, ' ').trim();
const gradeOf = s => s >= .30 ? 'A+' : s >= .20 ? 'A' : s >= .12 ? 'A-' : s >= .06 ? 'B+' : s > -.06 ? 'B' : s >= -.12 ? 'B-' : s >= -.20 ? 'C+' : s >= -.30 ? 'C' : s >= -.40 ? 'C-' : s >= -.55 ? 'D' : 'F';
const r1 = x => Math.round(x * 10) / 10;

// ---------- player value sources ----------
function extractJSON(text, marker) {
  let i = text.indexOf('var ' + marker); if (i < 0) i = text.indexOf(marker + ' =');
  if (i < 0) return null;
  const s = text.indexOf('{', i); if (s < 0) return null;
  let d = 0, str = false, esc = false;
  for (let k = s; k < text.length; k++) {
    const c = text[k];
    if (str) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') str = false; continue; }
    if (c === '"') str = true; else if (c === '{') d++; else if (c === '}' && --d === 0) return JSON.parse(text.slice(s, k + 1));
  }
  return null;
}
async function fetchFP(scoring) {
  const path = scoring === 'std' ? 'ros-overall' : scoring === 'half' ? 'ros-half-point-ppr-overall' : 'ros-ppr-overall';
  const r = await fetch(`https://www.fantasypros.com/nfl/rankings/${path}.php`, { headers: { 'User-Agent': UA, Accept: 'text/html' } });
  if (!r.ok) throw new Error('FantasyPros responded ' + r.status);
  const d = extractJSON(await r.text(), 'ecrData');
  const rows = ((d && d.players) || []).map(p => ({ name: p.player_name, rank: +(p.rank_ecr || p.rank_ave), pos: p.pos_rank || '' })).filter(p => p.name && p.rank);
  if (!rows.length) throw new Error('FantasyPros page format changed');
  return rows;
}
// Trade values come only from FantasyPros rest-of-season rankings (rank turned into a 0-100 value), saved for 6 hours.
// If FantasyPros cannot be read this throws, and callers report the values as unavailable instead of guessing.
async function getValues(env, week, scoring) {
  const key = `fp:${week}:${scoring}`;
  const hit = await kvGet(env, key);
  if (hit) return hit;
  const t = { week, scoring, players: {} };
  (await fetchFP(scoring)).forEach(p => { t.players[norm(p.name)] = { v: r1(100 * Math.exp(-0.028 * (p.rank - 1))), rk: p.pos }; });
  await kvPut(env, key, t, 6 * 3600);
  return t;
}

// Looks up a player who is no longer on any roster, using ESPN's public athlete pages (no login needed).
async function athleteName(id) {
  for (const url of [`https://site.web.api.espn.com/apis/common/v3/sports/football/nfl/athletes/${id}`,
                     `https://sports.core.api.espn.com/v2/sports/football/leagues/nfl/athletes/${id}?lang=en&region=us`]) {
    try {
      const r = await fetch(url, { headers: { 'User-Agent': UA } });
      if (!r.ok) continue;
      const j = await r.json(), a = j.athlete || j, name = a.fullName || a.displayName;
      if (name) { const pos = ((a.position && a.position.abbreviation) || '').replace('PK', 'K'); return { name, pos: OUT.includes(pos) ? pos : '', nfl: (a.team && a.team.abbreviation) || '' }; }
    } catch (e) { /* try the next address */ }
  }
  return null;
}

// ESPN stores a trade as several records: TRADE_PROPOSAL (holds the players), TRADE_ACCEPT, then TRADE_UPHOLD / TRADE_VETO votes.
// Only a proposal that was accepted is a trade. Each accept is matched to its proposal by the id ESPN gives it; if that is missing or does not
// check out, the nearby proposal whose players have actually moved to the new teams is used, so a declined offer is never mistaken for a trade.
const isSw = i => i.playerId != null && i.type !== 'DROP' && i.fromTeamId > 0 && i.toTeamId > 0 && i.fromTeamId !== i.toTeamId;
const movedShare = (p, ownerOf) => { const sw = (p.items || []).filter(isSw); return sw.length ? sw.filter(i => ownerOf[i.playerId] === i.toTeamId).length / sw.length : 0; };
function matchAccept(a, byId, props, ownerOf) {
  const linked = byId[a.relatedTransactionId];
  if (linked && (linked.items || []).some(isSw)) return linked;   // trust ESPN's own link between the accept and its offer
  // No usable link: only accept a nearby offer whose players have really moved. If none fits, the trade is left out rather than guessed.
  return props.filter(x => x.proposedDate <= a.proposedDate && a.proposedDate - x.proposedDate < 3 * 864e5 && movedShare(x, ownerOf) >= .99)
    .sort((x, y) => y.proposedDate - x.proposedDate)[0];
}
const swapKey = items => (items || []).filter(isSw).map(i => `${i.playerId}:${i.fromTeamId}>${i.toTeamId}`).sort().join('|');
function acceptedTrades(all, ownerOf = {}) {
  const byId = {};
  all.forEach(t => { if (t.id) byId[t.id] = t; });
  const props = all.filter(t => t.type === 'TRADE_PROPOSAL' && (t.items || []).some(isSw));
  const seen = new Set();
  return all.filter(t => t.type === 'TRADE_ACCEPT' || t.type === 'TRADE_ACCEPTED').sort((a, b) => a.proposedDate - b.proposedDate).map(a => {
    const p = matchAccept(a, byId, props, ownerOf);
    const items = ((a.items && a.items.length ? a.items : p && p.items) || []).filter(i => i.playerId != null);
    return items.length ? { id: a.id, ts: a.proposedDate, items } : null;
  }).filter(t => { if (!t) return false; const k = swapKey(t.items); if (seen.has(k)) return false; seen.add(k); return true; })   // one entry per trade
    .sort((x, y) => y.ts - x.ts);
}
const sigOf = s => { let x = 5381; for (const c of s) x = ((x << 5) + x + c.charCodeAt(0)) | 0; return (x >>> 0).toString(36); };

export default {
  async fetch(req, env, ctx) {
    const cors = { 'Access-Control-Allow-Origin': env.ALLOW_ORIGIN || '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS' };
    if (req.method === 'OPTIONS') return new Response(null, { headers: cors });
    const q = new URL(req.url).searchParams;
    const view = q.get('view') || 'transactions', debug = q.get('debug');
    const season = q.get('season') || new Date().getFullYear();
    const safe = s => String(s || '').replace(/[^\w-]/g, '').slice(0, 64);

    let gotwKey = null;
    try {
      // ----- storage-only routes (no ESPN needed) -----
      if (view === 'snapshot') {
        if (!env.KV) return json({ enabled: false }, cors);
        const k = `snap:${season}:${safe(q.get('week'))}`;
        if (req.method === 'POST') {
          if (!(await kvGet(env, k))) {   // first snapshot of the week wins
            const b = await req.json();
            await kvPut(env, k, { at: Date.now(), teams: (b.teams || []).slice(0, 40).map(t => ({ id: +t.id, rank: +t.rank, pct: +t.pct })) });
          }
          return json({ ok: true }, cors, 200, 0);
        }
        return json({ enabled: true, snap: await kvGet(env, k) }, cors, 200, 0);
      }
      if (debug === 'gemini') { const r = await gemini(env, 'Reply with the JSON {"ok":true}', 'ping', 60); return json({ ok: !!r.ok, model: env.GEMINI_MODEL || 'gemini-2.5-flash' }, cors); }
      if (view === 'tradeai') {   // AI summary for one trade, written once from details saved when the trade was graded
        if (!env.KV) return json({ error: 'AI summaries need the KV storage binding' }, cors, 404);
        const id = safe(q.get('id')), key = `ai:trade:${id}:${safe(q.get('sig'))}`, hit = await kvGet(env, key);
        if (hit) return json(hit, cors, 200, 600);
        const ctx = ((await kvGet(env, 'tradectx')) || {})[id];
        if (!ctx || (q.get('sig') && ctx.sig !== safe(q.get('sig')))) return json({ error: 'trade details are not saved yet; open the League tab first' }, cors, 404);
        const ai = await gemini(env, TRADE_PROMPT, JSON.stringify(ctx), 1500);
        const sides = (Array.isArray(ai.sides) ? ai.sides : []).map(x => ({ teamId: +x.teamId, summary: String(x.summary || '').slice(0, 480) })).filter(x => x.summary);
        if (!sides.length) return json({ error: 'Gemini returned no summary' }, cors, 502);
        const out = { sides, verdict: String(ai.verdict || '').slice(0, 320) };
        await kvPut(env, key, out);
        return json(out, cors, 200, 600);
      }
      if (view === 'gotwai') {   // cached for the week; a new week means a new key, so it resets by itself
        gotwKey = `ai:gotw:${season}:${+q.get('week') || 0}:${+q.get('a')}:${+q.get('b')}`;
        const hit = await kvGet(env, gotwKey);
        if (hit) return json(hit, cors, 200, 600);
      }
      const cache = !debug && CACHEABLE.includes(view) && typeof caches !== 'undefined' ? caches.default : null;
      if (cache) { const hit = await cache.match(req.url); if (hit) return hit; }
      const done = res => { if (cache && ctx && res.status === 200) ctx.waitUntil(cache.put(req.url, res.clone())); return res; };

      // ----- ESPN data -----
      const base = `${API}/${season}/segments/0/leagues/${env.LEAGUE_ID || q.get('leagueId')}`;
      const ask = async (qs, extra = {}) => {
        const r = await fetch(base + qs, { headers: { Cookie: `espn_s2=${env.ESPN_S2 || ''}; SWID=${env.SWID || ''}`, ...extra } });
        if (!r.ok) throw new Error('ESPN responded ' + r.status + ' ' + (await r.text()).slice(0, 200));
        return r.json();
      };
      const commFilter = { topics: { filterType: { value: ['ACTIVITY_TRANSACTIONS'] }, limit: 100, limitPerMessageSet: { value: 100 }, offset: 0,
        sortMessageDate: { direction: 'DESC', sortPriority: 1 }, sortFor: { direction: 'DESC', sortPriority: 2 } } };
      const comm = () => ask('/communication/?view=kona_league_communication', { 'X-Fantasy-Filter': JSON.stringify(commFilter) });
      const lg = await ask('?view=mTeam&view=mRoster');
      const cur = Math.max(1, Math.min(18, lg.scoringPeriodId || (lg.status && lg.status.currentMatchupPeriod) || 1));

      const name = {};
      (lg.teams || []).forEach(t => name[t.id] = t.name || `${t.location || ''} ${t.nickname || ''}`.trim());
      const first = {};
      (lg.members || []).forEach(m => first[m.id] = m.firstName || m.displayName);
      const info = t => {
        const r = (t.record && t.record.overall) || {};
        const g = (r.wins || 0) + (r.losses || 0) + (r.ties || 0);
        return { id: t.id, team: name[t.id], gm: (t.owners || []).map(o => first[o]).filter(Boolean).join(', '),
          record: `${r.wins || 0}-${r.losses || 0}` + (r.ties ? `-${r.ties}` : ''), wins: r.wins || 0,
          ppg: g ? Math.round((r.pointsFor || 0) / g * 10) / 10 : 0 };
      };
      const byId = {};
      (lg.teams || []).forEach(t => byId[t.id] = info(t));
      // A trade record can also hold roster-clearing drops (the player goes to no team). Those are not part of the swap.
      const isSwap = i => i.playerId != null && i.type !== 'DROP' && byId[i.toTeamId] && byId[i.fromTeamId] && i.toTeamId !== i.fromTeamId;
      const isDrop = i => i.playerId != null && !isSwap(i) && (byId[i.fromTeamId] || byId[i.toTeamId]);

      const rw = t => { const r = (t.record && t.record.overall) || {}; return (r.wins || 0) + .5 * (r.ties || 0); };
      const rpf = t => (t.record && t.record.overall && t.record.overall.pointsFor) || 0;
      const rankOf = {};
      [...(lg.teams || [])].sort((x, y) => rw(y) - rw(x) || rpf(y) - rpf(x)).forEach((t, i) => rankOf[t.id] = i + 1);
      const ownerOf = {};
      (lg.teams || []).forEach(t => ((t.roster && t.roster.entries) || []).forEach(en => { ownerOf[en.playerId != null ? en.playerId : (en.playerPoolEntry || {}).id] = t.id; }));
      // Transactions by week. Weeks more than two behind the current one are final, so they are saved once in KV and not requested again.
      const slim = t => ({ id: t.id, type: t.type, status: t.status, teamId: t.teamId, proposedDate: t.proposedDate, scoringPeriodId: t.scoringPeriodId,
        relatedTransactionId: t.relatedTransactionId, items: (t.items || []).map(i => ({ type: i.type, playerId: i.playerId, fromTeamId: i.fromTeamId, toTeamId: i.toTeamId })) });
      const worthKeeping = t => /^TRADE_(PROPOSAL|ACCEPT)/.test(t.type) || (t.status === 'EXECUTED' && (t.items || []).some(i => i.type === 'ADD' || i.type === 'DROP'));
      const rawTx = async () => {
        const top = Math.min(19, Math.max(cur, +q.get('week') || 0) + 1);   // one week ahead, in case ESPN's week has not rolled over yet
        const hist = (await kvGet(env, `txhist:${season}`)) || { upTo: -1, tx: [] };
        const from = Math.min(hist.upTo + 1, top);
        const got = await Promise.all(Array.from({ length: top - from + 1 }, (_, k) =>
          ask(`?view=mTransactions2&scoringPeriodId=${from + k}`).then(j => (j.transactions || []).filter(worthKeeping).map(slim)).catch(() => null)));
        let upTo = hist.upTo, add = [];
        for (let k = 0; k < got.length && got[k] && from + k <= top - 3; k++) { upTo = from + k; add = add.concat(got[k]); }   // stops at the first week that failed to load
        if (upTo > hist.upTo) await kvPut(env, `txhist:${season}`, { upTo, tx: hist.tx.concat(add) });
        const seen = new Set();
        return [...hist.tx, ...got.flatMap(g => g || [])].filter(t => !t.id || (!seen.has(t.id) && seen.add(t.id)));
      };
      // ESPN's Recent Activity feed lists completed trades only, player by player with the team each one left and joined.
      // It is the most direct source, so it wins for the period it covers; older trades come from the accept records.
      const feedTrades = async () => {
        try {
          const topics = (await comm()).topics || [], out = [];
          topics.forEach(tp => {
            const items = (tp.messages || []).filter(m => m.messageTypeId === 244 && m.targetId != null && m.from > 0 && m.to > 0 && m.from !== m.to)
              .map(m => ({ type: 'TRADE', playerId: m.targetId, fromTeamId: m.from, toTeamId: m.to }));
            if (items.length) out.push({ id: 'f' + sigOf(swapKey(items)), ts: tp.date || ((tp.messages || [])[0] || {}).date, items });
          });
          return { trades: out, oldest: topics.reduce((m, tp) => Math.min(m, tp.date || Infinity), Infinity), topics };
        } catch (e) { return { trades: [], oldest: Infinity, topics: [], error: String(e.message || e).slice(0, 100) }; }
      };
      const combinedTrades = async raw => {
        const acc = acceptedTrades(raw, ownerOf), fd = await feedTrades();
        if (!fd.trades.length) return acc;
        const idByKey = {};
        acc.forEach(t => idByKey[swapKey(t.items)] = t.id);   // keep ESPN's own id when both sources know the trade, so commissioner notes stay attached
        const fromFeed = fd.trades.map(t => ({ ...t, id: idByKey[swapKey(t.items)] || t.id }));
        const older = acc.filter(t => t.ts < fd.oldest && !fromFeed.some(f => swapKey(f.items) === swapKey(t.items)));
        return [...fromFeed, ...older].sort((x, y) => y.ts - x.ts);
      };
      // Names come from: current rosters, a saved list (every player ever seen on a roster stays in it), defenses,
      // one batch request to ESPN, and finally ESPN's public athlete pages for anyone still unknown.
      const resolvePlayers = async ids => {
        const out = {}, saved = (await kvGet(env, 'players')) || {};
        let changed = false;
        (lg.teams || []).forEach(t => ((t.roster && t.roster.entries) || []).forEach(en => {
          const p = en.playerPoolEntry && en.playerPoolEntry.player;
          if (!p) return;
          const v = { name: p.fullName, pos: POS[p.defaultPositionId] || '', nfl: NFL[p.proTeamId] || '' };
          out[p.id] = v;
          if (!saved[p.id] || saved[p.id].nfl !== v.nfl || saved[p.id].name !== v.name) { saved[p.id] = v; changed = true; }
        }));
        let need = ids.filter(i => !out[i]);
        need = need.filter(i => {
          if (saved[i]) { out[i] = saved[i]; return false; }
          if (i < 0) { const t = NFL[-i - 16000]; out[i] = { name: t ? `${t} D/ST` : 'a team defense', pos: 'D/ST', nfl: t || '' }; return false; }
          return true;
        });
        if (need.length) {
          try {
            const pj = await ask('?view=kona_playercard', { 'X-Fantasy-Filter': JSON.stringify({ players: { filterIds: { value: need } } }) });
            (pj.players || []).forEach(p => { const pp = p.player || p; if (pp.fullName) { out[p.id] = saved[p.id] = { name: pp.fullName, pos: POS[pp.defaultPositionId] || '', nfl: NFL[pp.proTeamId] || '' }; changed = true; } });
          } catch (e) { /* the public athlete pages below cover anyone still unknown */ }
          need = need.filter(i => !out[i]);
        }
        if (need.length) {   // capped so a request stays under the free plan's subrequest limit; the rest are filled in on later refreshes
          const found = await Promise.all(need.slice(0, 12).map(async i => [i, await athleteName(i)]));
          found.forEach(([i, v]) => { if (v) { out[i] = saved[i] = v; changed = true; } });
        }
        if (changed) await kvPut(env, 'players', saved);
        return out;
      };
      const nm = (P, i) => (P[i] && P[i].name) || (i < 0 ? 'a team defense' : 'player #' + i);
      let settingsP;
      const settings = () => settingsP || (settingsP = ask('?view=mSettings').catch(() => ({})));
      const scoringKind = async () => {
        const it = ((((await settings()).settings || {}).scoringSettings || {}).scoringItems || []).find(i => i.statId === 53);
        const pts = it ? +it.points : 1;
        return pts >= 1 ? 'ppr' : pts > 0 ? 'half' : 'std';
      };
      const slotsOf = async () => {
        const lc = ((((await settings()).settings || {}).rosterSettings || {}).lineupSlotCounts) || {};
        return { QB: lc[0] != null ? lc[0] : 1, RB: lc[2] != null ? lc[2] : 2, WR: lc[4] != null ? lc[4] : 2, TE: lc[6] != null ? lc[6] : 1, FLEX: lc[23] || 0, SUPERFLEX: lc[7] || 0 };
      };

      if (debug === 'tradelog') {   // readable log of every trade record ESPN holds, oldest first (the most recent 40), plus the activity feed
        const all = await rawTx(), byId2 = {};
        all.forEach(t => { if (t.id) byId2[t.id] = t; });
        const rows = all.filter(t => /TRADE/.test(t.type)).sort((a, b) => a.proposedDate - b.proposedDate).slice(-40);
        const fd = await feedTrades();
        const P = await resolvePlayers([...new Set([...rows, ...fd.trades].flatMap(t => (t.items || []).map(i => i.playerId)))].filter(i => i != null));
        const tn = id => name[id] || id, pn = id => `${nm(P, id)} [${id}]`, iso = ms => new Date(ms).toISOString().slice(5, 16).replace('T', ' ');
        const counts = {}; all.forEach(t => counts[t.type] = (counts[t.type] || 0) + 1);
        const lines = ['RECORD COUNTS: ' + JSON.stringify(counts), ''];
        rows.forEach(t => {
          const r = byId2[t.relatedTransactionId];
          lines.push(`${iso(t.proposedDate)} ${String(t.type).replace('TRADE_', '')} ${t.status || '-'} by ${tn(t.teamId)} id ${String(t.id).slice(0, 6)} rel ${t.relatedTransactionId ? String(t.relatedTransactionId).slice(0, 6) + (r ? ' (' + String(r.type).replace('TRADE_', '') + ')' : ' (not found)') : '-'} | ` +
            (t.items || []).map(i => `${pn(i.playerId)} ${i.type === 'DROP' ? 'dropped by ' : ''}${tn(i.fromTeamId)}>${tn(i.toTeamId)}`).join('; '));
        });
        const mt = {}; fd.topics.forEach(tp => (tp.messages || []).forEach(m => mt[m.messageTypeId] = (mt[m.messageTypeId] || 0) + 1));
        lines.push('', `ACTIVITY FEED: ${fd.topics.length} entries, oldest ${fd.oldest === Infinity ? '-' : iso(fd.oldest)}, message types ${JSON.stringify(mt)}${fd.error ? ', error ' + fd.error : ''}`);
        fd.topics.flatMap(tp => (tp.messages || []).filter(m => !ACTIVITY[m.messageTypeId])).slice(0, 6).forEach(m => lines.push('  other message: ' + JSON.stringify(m).slice(0, 260)));
        fd.trades.slice(0, 6).forEach(t => lines.push(`  FEED TRADE ${iso(t.ts)} | ` + t.items.map(i => `${pn(i.playerId)} ${tn(i.fromTeamId)}>${tn(i.toTeamId)}`).join('; ')));
        lines.push('', 'TRADES THE APP SHOWS:');
        (await combinedTrades(all)).slice(0, 12).forEach(t => lines.push(`  ${String(t.id).slice(0, 6)} ${iso(t.ts)} | ` + t.items.filter(isSw).map(i => `${pn(i.playerId)} ${tn(i.fromTeamId)}>${tn(i.toTeamId)}`).join('; ')));
        return new Response(lines.join('\n'), { headers: { ...cors, 'Content-Type': 'text/plain; charset=utf-8' } });
      }

      if (view === 'values') {   // warms the FantasyPros values in their own request so the trades request stays light
        try { const t = await getValues(env, +q.get('week') || cur, await scoringKind()); return json({ available: true, count: Object.keys(t.players).length }, cors, 200, 600); }
        catch (e) { return json({ available: false, error: String(e.message || e).slice(0, 140) }, cors, 200, 0); }
      }

      if (view === 'teams') {
        return done(json(Object.values(byId).map(t => ({ id: t.id, name: t.team, owner: t.gm, record: t.record, ppg: t.ppg })), cors));
      }

      if (view === 'gotw') {
        const week = +q.get('week') || cur;
        const mj = await ask(`?view=mMatchupScore&scoringPeriodId=${week}`);
        const games = (mj.schedule || [])
          .filter(m => m.matchupPeriodId === week && m.home && m.away && byId[m.home.teamId] && byId[m.away.teamId])
          .map(m => { const a = byId[m.home.teamId], b = byId[m.away.teamId];
            return { a, b, score: (a.wins + b.wins) * 100 - Math.abs(a.ppg - b.ppg) + (a.ppg + b.ppg) / 10 }; })
          .sort((x, y) => y.score - x.score);
        if (!games.length) return json({ error: 'no matchups found for week ' + week }, cors, 404);
        return done(json({ week, a: games[0].a, b: games[0].b, games: games.length }, cors));
      }

      if (view === 'standings') {
        const sj = await ask('?view=mSettings&view=mMatchupScore');
        const ss = (sj.settings && sj.settings.scheduleSettings) || {};
        const regWeeks = ss.matchupPeriodCount || 14;
        const remaining = (sj.schedule || [])
          .filter(m => m.winner === 'UNDECIDED' && m.matchupPeriodId <= regWeeks && m.home && m.away)
          .map(m => ({ a: m.home.teamId, b: m.away.teamId, w: m.matchupPeriodId }));
        const teams = (lg.teams || []).map(t => {
          const r = (t.record && t.record.overall) || {};
          return { ...byId[t.id], losses: r.losses || 0, ties: r.ties || 0, pf: r1(r.pointsFor || 0),
            pa: r1(r.pointsAgainst || 0), games: (r.wins || 0) + (r.losses || 0) + (r.ties || 0) };
        });
        return done(json({ week: cur, regWeeks, playoffTeams: ss.playoffTeamCount || 6, teams, remaining }, cors));
      }

      if (view === 'totw') {
        const week = +q.get('week') || Math.max(1, cur - 1);
        const bj = await ask(`?view=mMatchup&view=mMatchupScore&view=mBoxscore&scoringPeriodId=${week}`);
        const pool = [];
        for (const m of bj.schedule || []) {
          if (m.matchupPeriodId !== week) continue;
          for (const side of [m.home, m.away]) {
            if (!side) continue;
            const entries = (side.rosterForCurrentScoringPeriod || side.rosterForMatchupPeriod || {}).entries || [];
            for (const e of entries) {
              const pe = e.playerPoolEntry || {}, p = pe.player || {}, pos = POS[p.defaultPositionId];
              if (!pos) continue;
              pool.push({ pos, name: p.fullName, pts: r1(pe.appliedStatTotal || 0), nfl: NFL[p.proTeamId] || '', teamId: side.teamId,
                team: name[side.teamId], gm: (byId[side.teamId] || {}).gm || '', started: ![20, 21].includes(e.lineupSlotId) });
            }
          }
        }
        const take = (pos, n) => pool.filter(x => x.pos === pos).sort((a, b) => b.pts - a.pts).slice(0, n);
        const lineup = [...take('QB', 1), ...take('RB', 2), ...take('WR', 2), ...take('TE', 1), ...take('K', 1)];
        return done(json({ week, lineup, scanned: pool.length }, cors));
      }

      // ----- Game of the Week AI preview -----
      if (view === 'gotwai') {
        const week = +q.get('week') || cur, A = byId[+q.get('a')], B = byId[+q.get('b')];
        if (!A || !B) return json({ error: 'unknown team' }, cors, 404);
        const vt = await kvGet(env, `fp:${week}:${await scoringKind()}`), slots = await slotsOf();
        const team = id => {
          const t = (lg.teams || []).find(x => x.id === id), r = (t.record && t.record.overall) || {}, g = (r.wins || 0) + (r.losses || 0) + (r.ties || 0);
          const entries = ((t.roster && t.roster.entries) || []).map(en => {
            const p = (en.playerPoolEntry || {}).player || {};
            return { name: p.fullName, pos: POS[p.defaultPositionId] || '', v: vt ? ((vt.players[norm(p.fullName)] || {}).v || 0) : 0, slot: en.lineupSlotId,
              inj: p.injuryStatus && p.injuryStatus !== 'ACTIVE' ? p.injuryStatus : '' };
          });
          const starters = entries.filter(e => ![20, 21].includes(e.slot) && ['QB', 'RB', 'WR', 'TE'].includes(e.pos)).sort((x, y) => y.v - x.v);
          return { gm: byId[id].gm, team: byId[id].team, record: byId[id].record, standingsRank: rankOf[id], pointsPerGame: byId[id].ppg,
            pointsAllowedPerGame: g ? r1((r.pointsAgainst || 0) / g) : 0, topStarters: starters.slice(0, 7).map(s => `${s.name} ${s.pos}${s.v ? ' (value ' + s.v + ')' : ''}`),
            injuredStarters: starters.filter(s => s.inj).map(s => `${s.name} (${s.inj})`), lineupStrength: r1(lineupOf(entries, slots).total) };
        };
        const ai = await gemini(env, GOTW_PROMPT, JSON.stringify({ week, teamA: team(A.id), teamB: team(B.id) }), 700);
        const preview = String(ai.preview || '').slice(0, 700);
        if (!preview) return json({ error: 'Gemini returned no preview' }, cors, 502);
        await kvPut(env, gotwKey, { preview }, 8 * 86400);
        return json({ preview }, cors, 200, 600);
      }

      // ----- trades: completed, accepted trades only, graded for each roster, saved for the AI summary -----
      if (view === 'trades') {
        // A trade still in the league review period (players not moved yet) stays hidden until it goes through.
        const trades = (await combinedTrades(await rawTx()))
          .filter(t => !(Date.now() - t.ts < 4 * 864e5 && (t.items || []).some(i => isSwap(i) && ownerOf[i.playerId] === i.fromTeamId)))
          .slice(0, 12);
        const wk = +q.get('week') || cur, kind = await scoringKind(), slots = await slotsOf();
        let vt = null, valuesStatus = { available: true };
        try { vt = await getValues(env, wk, kind); } catch (e) { valuesStatus = { available: false, error: String(e.message || e).slice(0, 140) }; }
        const have = !!vt;
        const source = have ? 'Values from FantasyPros rest-of-season rankings.' : 'Trade values are unavailable because FantasyPros could not be read, so there are no grades or AI summaries right now.';
        const P = await resolvePlayers([...new Set(trades.flatMap(t => (t.items || []).map(i => i.playerId)))].filter(i => i != null));
        const val = n => (have && vt.players[norm(n)]) || { v: have ? 1 : 0, rk: '' };   // a player FantasyPros does not rank counts as 1
        const rosters = {};
        (lg.teams || []).forEach(t => rosters[t.id] = ((t.roster && t.roster.entries) || []).map(en => {
          const p = (en.playerPoolEntry && en.playerPoolEntry.player) || {};
          return { name: p.fullName, pos: POS[p.defaultPositionId] || '', v: val(p.fullName).v };
        }));
        const DEPTH = [1, .8, .6, .45, .35];
        const tot = a => a.slice().sort((x, y) => y.v - x.v).reduce((s, x, i) => s + x.v * DEPTH[Math.min(i, 4)], 0);
        const brief = p => `${p.name} ${p.pos}${p.nfl ? ' ' + p.nfl : ''} (value ${p.v}${p.rk ? ', ' + p.rk : ''})`;
        const topBy = r => { const o = {}; ['QB', 'RB', 'WR', 'TE'].forEach(pos => o[pos] = r.filter(x => x.pos === pos).sort((a, b) => b.v - a.v).slice(0, 4).map(x => `${x.name} (${r1(x.v)})`)); return o; };
        const ctxStore = {};

        const out = trades.map(t => {
          const sides = {};
          for (const i of t.items || []) {
            if (i.playerId == null) continue;
            const v = val(nm(P, i.playerId));
            const p = { name: nm(P, i.playerId), pos: (P[i.playerId] || {}).pos || '', nfl: (P[i.playerId] || {}).nfl || '', v: r1(v.v), rk: v.rk || '' };
            const side = id => (sides[id] = sides[id] || { gets: [], gives: [], drops: [] });
            if (isSwap(i)) { side(i.toTeamId).gets.push(p); side(i.fromTeamId).gives.push(p); }
            else if (isDrop(i)) side(byId[i.fromTeamId] ? i.fromTeamId : i.toTeamId).drops.push({ name: p.name, pos: p.pos });
          }
          const ctxSides = [];
          const list = Object.entries(sides).filter(([, sd]) => sd.gets.length || sd.gives.length).map(([tid, sd]) => {
            const R = tot(sd.gets), S = tot(sd.gives), gm = (byId[tid] || {}).gm || name[tid];
            const roster = rosters[tid] || [], got = new Set(sd.gets.map(g => g.name));
            // lineup before and after: today's roster is "after"; "before" swaps the traded players back
            const post = roster.map(r => ({ ...r }));
            sd.gets.forEach(g => { if (!post.some(r => r.name === g.name)) post.push({ name: g.name, pos: g.pos, v: g.v }); });
            const pre = post.filter(r => !got.has(r.name)).concat(sd.gives.map(g => ({ name: g.name, pos: g.pos, v: g.v })));
            const lb = lineupOf(pre, slots), la = lineupOf(post, slots), delta = la.total - lb.total;
            const net = .7 * delta + .3 * (R - S), s = net / Math.max(R, S, 25);   // starting-lineup change counts most, raw value second
            const bits = [];
            for (const pos of OUT) {
              const a = sd.gets.filter(g => g.pos === pos).sort((x, y) => y.v - x.v)[0];
              if (!a) continue;
              const best = roster.filter(r => r.pos === pos && !got.has(r.name)).sort((x, y) => y.v - x.v)[0];
              if (a.v >= 60 && best && best.v >= 55) bits.push(`stacks the ${pos} room by pairing ${a.name} with ${best.name}`);
              else if (a.v >= 50 && (!best || best.v < 35)) bits.push(`fills a real hole at ${pos} with ${a.name}`);
            }
            for (const pos of OUT) {
              const g = sd.gives.filter(x => x.pos === pos).sort((x, y) => y.v - x.v)[0];
              if (!g || g.v < 50) continue;
              const left = roster.filter(r => r.pos === pos).sort((x, y) => y.v - x.v)[0];
              if (!left || left.v < 40) bits.push(`thins out the ${pos} room by sending away ${g.name}`);
            }
            const gt = sd.gets.slice().sort((x, y) => y.v - x.v)[0], gg = sd.gives.slice().sort((x, y) => y.v - x.v)[0];
            if (gt && gg && sd.gets.length < sd.gives.length && gt.v >= gg.v && !bits.some(b => b.includes(gt.name))) bits.push(`consolidates depth into ${gt.name}`);
            else if (gt && gg && sd.gets.length > sd.gives.length && gt.v < gg.v) bits.push('swaps a top piece for quantity');
            const note = bits.length ? `${gm} ${bits.slice(0, 2).join(' and ')}.` : `${gm} makes a depth move that should not change much.`;
            ctxSides.push({ teamId: +tid, gm, team: name[tid], record: (byId[tid] || {}).record, standingsRank: rankOf[tid], received: sd.gets.map(brief), sent: sd.gives.map(brief),
              droppedToMakeRoom: sd.drops.map(d => d.name), lineupBefore: lb.starters.map(x => `${x.slot}: ${x.name} (${r1(x.v)})`), lineupAfter: la.starters.map(x => `${x.slot}: ${x.name} (${r1(x.v)})`),
              lineupChange: r1(delta), topPlayersByPosition: topBy(post.filter(r => !sd.drops.some(d => d.name === r.name))), calculatedGrade: have ? gradeOf(s) : null });
            return { teamId: +tid, id: +tid, team: name[tid], gm, record: (byId[tid] || {}).record, rank: rankOf[tid], gets: sd.gets, drops: sd.drops,
              total: have ? r1(R) : null, grade: have ? gradeOf(s) : null, note: have ? note : '', s, R, S };
          });
          let verdict = '';
          if (have && list.length === 2) {
            const w = list[0].s >= list[1].s ? list[0] : list[1];
            verdict = Math.abs(w.s) < .06 ? 'Close to a fair swap on the numbers.' : `${w.gm} wins on value, coming out about ${Math.round(w.R - w.S)} points ahead.`;
          }
          if (have) ctxStore[String(t.id)] = { league: { scoring: kind.toUpperCase(), startingLineup: slots }, sides: ctxSides };
          const sig = sigOf(list.map(x => x.teamId + ':' + x.gets.map(g => g.name).join(',')).sort().join('|'));
          if (have) ctxStore[String(t.id)] = { ...ctxStore[String(t.id)], sig };
          return { id: String(t.id), sig, ts: t.ts, verdict, sides: list.map(({ s, R, S, ...rest }) => rest) };
        });
        const saved = (await kvGet(env, 'tradectx')) || {};
        let changed = false;
        for (const [id, c] of Object.entries(ctxStore)) if (!saved[id] || saved[id].sig !== c.sig) { saved[id] = c; changed = true; }
        const keys = Object.keys(saved);
        if (keys.length > 40) { keys.slice(0, keys.length - 40).forEach(k => delete saved[k]); changed = true; }
        if (changed) await kvPut(env, 'tradectx', saved);
        return done(json({ trades: out, source, valuesStatus }, cors));
      }

      if (view !== 'transactions' || (debug && debug !== 'tradelog')) return json({ error: 'unknown view' }, cors, 404);

      // ----- transactions -----
      const raw = await rawTx();
      let tx = raw.filter(t => t.status === 'EXECUTED');
      if (!tx.length) {
        try {
          const cj = await comm();
          (cj.topics || []).forEach(tp => (tp.messages || []).forEach(m => {
            const a = ACTIVITY[m.messageTypeId];
            if (!a) return;
            tx.push({ status: 'EXECUTED', type: a[0], teamId: m.for != null ? m.for : m.to, proposedDate: m.date || tp.date, items: [{ type: a[1], playerId: m.targetId }] });
          }));
        } catch (e) { /* feed unavailable */ }
      }
      tx = tx.sort((a, b) => b.proposedDate - a.proposedDate).slice(0, 40);
      const trs = (await combinedTrades(raw)).slice(0, 10);
      const P = await resolvePlayers([...new Set([...tx, ...trs].flatMap(t => (t.items || []).map(i => i.playerId)))].filter(i => i != null));
      const out = tx.map(t => {
        const items = t.items || [];
        if (t.type === 'TRADE_ACCEPTED') {
          const sides = {};
          items.forEach(i => (sides[i.fromTeamId] = sides[i.fromTeamId] || []).push(nm(P, i.playerId)));
          return { type: 'TRADE', text: 'Trade: ' + Object.entries(sides).map(([id, ps]) => `${name[id]} sends ${ps.join(', ')}`).join('; '), ts: t.proposedDate };
        }
        const adds = items.filter(i => i.type === 'ADD').map(i => nm(P, i.playerId));
        const drops = items.filter(i => i.type === 'DROP').map(i => nm(P, i.playerId));
        if (!adds.length && !drops.length) return null;
        const w = String(t.type).startsWith('WAIVER'), parts = [];
        if (adds.length) parts.push(`${w ? 'won' : 'added'} ${adds.join(', ')}`);
        if (drops.length) parts.push(`dropped ${drops.join(', ')}`);
        return { type: w ? 'WAIVER' : adds.length ? 'ADD' : 'DROP', text: `${name[t.teamId]} ${parts.join(' and ')}`, ts: t.proposedDate };
      }).filter(Boolean);
      const tradeRows = trs.map(t => {
        const sides = {};
        t.items.filter(isSwap).forEach(i => (sides[i.fromTeamId] = sides[i.fromTeamId] || []).push(nm(P, i.playerId)));
        return { type: 'TRADE', text: 'Trade: ' + Object.entries(sides).map(([id, ps]) => `${name[id]} sends ${ps.join(', ')}`).join('; '), ts: t.ts };
      });
      return done(json([...out, ...tradeRows].sort((a, b) => b.ts - a.ts), cors));
    } catch (e) {
      return json({ error: String(e && e.message || e) }, cors, 502);
    }
  }
};
