#!/usr/bin/env python3
"""Safe editor for data/commish-thoughts.json (add, update, delete, validate).

  python3 tools/commish.py set <trade-id> "Your commentary" [--file data/commish-thoughts.json]
  python3 tools/commish.py delete <trade-id>
  python3 tools/commish.py validate

Only the named entry changes; every other entry is kept exactly as it was.
"""
import datetime, json, sys

def load(path):
    try:
        with open(path, encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        return {}
    if not isinstance(data, dict):
        raise SystemExit(f'{path}: top level must be an object keyed by trade id')
    return data

def check(data):
    for tid, e in data.items():
        if not isinstance(tid, str) or not tid.strip():
            raise SystemExit('every key must be a non-empty trade id string')
        if not isinstance(e, dict) or not isinstance(e.get('commentary'), str) or not e['commentary'].strip():
            raise SystemExit(f'{tid}: needs a non-empty "commentary" string')
        if 'updatedAt' in e and not isinstance(e['updatedAt'], str):
            raise SystemExit(f'{tid}: "updatedAt" must be a string like 2026-10-08')

def save(path, data):
    check(data)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write('\n')

def main(argv):
    path = 'data/commish-thoughts.json'
    if '--file' in argv:
        i = argv.index('--file'); path = argv[i + 1]; del argv[i:i + 2]
    cmd = argv[0] if argv else ''
    data = load(path)
    if cmd == 'validate':
        check(data); print(f'{path}: ok, {len(data)} entries')
    elif cmd == 'set' and len(argv) == 3:
        data[argv[1]] = {'commentary': argv[2].strip(), 'updatedAt': datetime.date.today().isoformat()}
        save(path, data); print(f'saved {argv[1]}')
    elif cmd == 'delete' and len(argv) == 2:
        if argv[1] not in data: raise SystemExit('no entry with that id')
        del data[argv[1]]; save(path, data); print(f'deleted {argv[1]}')
    else:
        raise SystemExit(__doc__)

if __name__ == '__main__':
    main(sys.argv[1:])
